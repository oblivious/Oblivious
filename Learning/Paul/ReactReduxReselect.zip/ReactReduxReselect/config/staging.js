module.exports = {
    env: "staging"   
};